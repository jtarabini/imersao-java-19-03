package br.com.targettrust.locadora.entidades;

public class Moto extends Veiculo {
	
	private Integer cilindradas;

	public Integer getCilindradas() {
		return cilindradas;
	}

	public void setCilindradas(Integer cilindradas) {
		this.cilindradas = cilindradas;
	}
	
	

}
