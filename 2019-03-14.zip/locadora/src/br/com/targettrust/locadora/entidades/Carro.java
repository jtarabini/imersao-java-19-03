package br.com.targettrust.locadora.entidades;

public class Carro {
	
	private Integer portas;

	public Integer getPortas() {
		return portas;
	}

	public void setPortas(Integer portas) {
		this.portas = portas;
	}
	

}
