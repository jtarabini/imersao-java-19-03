package br.com.targettrust.traccadastros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TracCadastrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TracCadastrosApplication.class, args);
	}

}
